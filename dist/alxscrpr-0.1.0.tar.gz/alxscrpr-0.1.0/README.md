**How to Install Python .Whl (Wheel) File**

The most popular way to install the new Python package or library is to use pip. When that's not possible you can instead 
install a new Python package with a .whl file. Python wheel file ```.whl``` file is a specially formatted zip archive as
a Python built-package. It contains all the installation files and may be installed by simply unpacking the file.


1. Check if pip is already [installed](https://pip.pypa.io/en/stable/installing/). 
    If pip.exe is not recognized, install it.

2. Download the .whl file 
   You could download the unofficial windows binary for Python extension packages from this trustable [UCI website](https://www.lfd.uci.edu/~gohlke/pythonlibs/#jpype).

3. Install .whl file 
   For example, if you have downloaded ```this_package.whl``` to the folder ```C:\Downloads\```. 
   Use pip install ```C:\Downloads\this_package.whl``` to install the whl package file.

4. Run the CLI from terminal / command line by typing ```alxscrpr start```