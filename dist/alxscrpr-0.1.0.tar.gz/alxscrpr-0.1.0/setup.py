# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['alxscrpr']

package_data = \
{'': ['*']}

install_requires = \
['typer[all]>=0.3.2,<0.4.0']

entry_points = \
{'console_scripts': ['alxscrpr = alxscrpr.main:app']}

setup_kwargs = {
    'name': 'alxscrpr',
    'version': '0.1.0',
    'description': '',
    'long_description': "**How to Install Python .Whl (Wheel) File**\n\nThe most popular way to install the new Python package or library is to use pip. When that's not possible you can instead \ninstall a new Python package with a .whl file. Python wheel file ```.whl``` file is a specially formatted zip archive as\na Python built-package. It contains all the installation files and may be installed by simply unpacking the file.\n\n\n1. Check if pip is already [installed](https://pip.pypa.io/en/stable/installing/). \n    If pip.exe is not recognized, install it.\n\n2. Download the .whl file \n   You could download the unofficial windows binary for Python extension packages from this trustable [UCI website](https://www.lfd.uci.edu/~gohlke/pythonlibs/#jpype).\n\n3. Install .whl file \n   For example, if you have downloaded ```this_package.whl``` to the folder ```C:\\Downloads\\```. \n   Use pip install ```C:\\Downloads\\this_package.whl``` to install the whl package file.\n\n4. Run the CLI from terminal / command line by typing ```alxscrpr start```",
    'author': 'Alex Turner',
    'author_email': 'none',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
